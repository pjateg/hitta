# Requirements
Brain Cells\
Python 3\
Ms Accs with Payment Method Linked\
Residential Proxies ( Not compulsory )

# How to use?

Put accounts in accs.txt\
Put proxies in proxies.txt\
Run main.py

# ProductIds and SkuIds
C0F5HT9NV86P | 0X3J  V-BUCKS\
9NQGKTXR9BZF | 0010  MINECRAFT DELUXE + JAVA + BEDROCK\
9NXP44L49SHJ | 0010  MINECRAFT JAVA + BEDROCK\
9N5253J559LR | 0010  Five Nights at Freddy's\
BS5KH5D3QQWV | 0X3J  400 Robux for Xbox\
9ng07qjnk38j | 0010  AMONG US\
9pcm4cmtppgc | 0010  LIES OF P\
9nmpdq2nrx34 | 0010  STRAY\
CFQ7TTC0KHS0 | 0008 || XBOX GP 3 Month

# I'm having issues with the purchaser. Where should I ask for help?

[GOGLE](https://www.google.com/)\
[GPT](https://chat.openai.com/)
# Contact

Discord : _notlit12#0000 [ Do Not DM ME for Help/Issues related to the tool]


